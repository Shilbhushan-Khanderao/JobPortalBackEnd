package com.JobPortal.controller;

public class ApplicationController {

}
