package com.JobPortal.daoimpl;

import com.JobPortal.dao.ApplicationDao;
import com.JobPortal.pojo.Application;

public class ApplicationDaoImpl implements ApplicationDao {

	@Override
	public Application view() {
		// TODO Auto-generated method stub
		return null;
	}

}
