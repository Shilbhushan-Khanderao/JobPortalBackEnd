package com.JobPortal.dao;

import com.JobPortal.pojo.Application;

public interface ApplicationDao {
	
	Application view();
}
